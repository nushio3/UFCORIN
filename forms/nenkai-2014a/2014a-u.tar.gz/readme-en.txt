% readme-en.txt

Please read the following instructions carefully.

* DUE DATE FOR APPLICATION

    Start: NOON  3 December 2013
    End:   NOON 10 December 2013

* HOW TO SUBMIT

 1. Edit the sample file `sample-en.tex'.  And confirm that
        - no error occurs when `latex'ing it.
	- the abstract is fitted in ONE page.
    The coded character sets you can use in the draft are US-ASCII
    and JIS X 0208.
    Do not use any commands to improve the appearance, for example,
    spacing or breaking, for the data except but the main body.

 2. Submit it to
		abs2014a@nenkai.asj.or.jp
    as plain text or attached file.
    If you apply two or three presentations, submit the applications
    for them SEPARATELY.

 3. You receive the notification immediately.  Read it carefully.
    If the application is rejected, send the revised one.

* NOTES

  - We use `pTeX' for compiling.
  - You cannot modify the abstract after it has been accepted.
  - The abstract will be published in the WWW.
  - You can get the latest information from
	http://www.asj.or.jp/nenkai/abs/

				The annual meeting committee
% EOF
